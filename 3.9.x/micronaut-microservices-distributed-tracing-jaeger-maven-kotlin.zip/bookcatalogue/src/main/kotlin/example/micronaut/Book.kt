package example.micronaut

data class Book(var isbn: String, val name: String)