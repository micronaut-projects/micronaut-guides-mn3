package example.micronaut

interface BookFetcher {

    List<Book> fetchBooks()
}
