package example.micronaut

interface ApplicationConfiguration {

    int getMax()
}
