package example.twitter.api;

import example.twitter.model.Error;
import example.twitter.model.GenericMultipleUsersLookupResponse;
import example.twitter.model.MultiUserLookupResponse;
import example.twitter.model.Problem;
import java.util.Set;
import example.twitter.model.SingleUserLookupResponse;
import example.twitter.model.UsersBlockingMutationResponse;
import example.twitter.model.UsersFollowingCreateResponse;
import example.twitter.model.UsersFollowingDeleteResponse;
import example.twitter.model.UsersFollowingLookupResponse;
import example.twitter.model.UsersIdBlockRequest;
import example.twitter.model.UsersMutingMutationResponse;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import jakarta.inject.Inject;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.HashSet;


/**
 * API tests for UsersApi
 */
@MicronautTest
public class UsersApiTest {

    @Inject
    UsersApi api;

    
    /**
     * User lookup by ID
     *
     * This endpoint returns information about a user. Specify user by ID.
     */
    @Test
    @Disabled("Not Implemented")
    public void findUserByIdTest() {
        // given
        String id = "2244994945";
        Set<String> expansions = new HashSet<>();
        Set<String> tweetFields = new HashSet<>();
        Set<String> userFields = new HashSet<>();

        // when
        SingleUserLookupResponse body = api.findUserById(id, expansions, tweetFields, userFields).block();

        // then
        // TODO implement the findUserByIdTest()
    }

    
    /**
     * User lookup by username
     *
     * This endpoint returns information about a user. Specify user by username.
     */
    @Test
    @Disabled("Not Implemented")
    public void findUserByUsernameTest() {
        // given
        String username = "TwitterDev";
        Set<String> expansions = new HashSet<>();
        Set<String> tweetFields = new HashSet<>();
        Set<String> userFields = new HashSet<>();

        // when
        SingleUserLookupResponse body = api.findUserByUsername(username, expansions, tweetFields, userFields).block();

        // then
        // TODO implement the findUserByUsernameTest()
    }

    
    /**
     * User lookup by IDs
     *
     * This endpoint returns information about users. Specify users by their ID.
     */
    @Test
    @Disabled("Not Implemented")
    public void findUsersByIdTest() {
        // given
        List<String> ids = Arrays.asList("example");
        Set<String> expansions = new HashSet<>();
        Set<String> tweetFields = new HashSet<>();
        Set<String> userFields = new HashSet<>();

        // when
        MultiUserLookupResponse body = api.findUsersById(ids, expansions, tweetFields, userFields).block();

        // then
        // TODO implement the findUsersByIdTest()
    }

    
    /**
     * User lookup by usernames
     *
     * This endpoint returns information about users. Specify users by their username.
     */
    @Test
    @Disabled("Not Implemented")
    public void findUsersByUsernameTest() {
        // given
        List<String> usernames = Arrays.asList("example");
        Set<String> expansions = new HashSet<>();
        Set<String> tweetFields = new HashSet<>();
        Set<String> userFields = new HashSet<>();

        // when
        MultiUserLookupResponse body = api.findUsersByUsername(usernames, expansions, tweetFields, userFields).block();

        // then
        // TODO implement the findUsersByUsernameTest()
    }

    
    /**
     * Returns user objects that have liked the provided Tweet ID
     *
     * Returns a list of users that have liked the provided Tweet ID
     */
    @Test
    @Disabled("Not Implemented")
    public void tweetsIdLikingUsersTest() {
        // given
        String id = "example";

        // when
        GenericMultipleUsersLookupResponse body = api.tweetsIdLikingUsers(id).block();

        // then
        // TODO implement the tweetsIdLikingUsersTest()
    }

    
    /**
     * Returns user objects that have retweeted the provided Tweet ID
     *
     * Returns a list of users that have retweeted the provided Tweet ID
     */
    @Test
    @Disabled("Not Implemented")
    public void tweetsIdRetweetingUsersTest() {
        // given
        String id = "example";

        // when
        GenericMultipleUsersLookupResponse body = api.tweetsIdRetweetingUsers(id).block();

        // then
        // TODO implement the tweetsIdRetweetingUsersTest()
    }

    
    /**
     * Block User by User ID
     *
     * Causes the user (in the path) to block the target user. The user (in the path) must match the user context authorizing the request
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdBlockTest() {
        // given
        String id = "example";
        UsersIdBlockRequest usersIdBlockRequest = new UsersIdBlockRequest("example");

        // when
        UsersBlockingMutationResponse body = api.usersIdBlock(id, usersIdBlockRequest).block();

        // then
        // TODO implement the usersIdBlockTest()
    }

    
    /**
     * Returns user objects that are blocked by provided user ID
     *
     * Returns a list of users that are blocked by the provided user ID
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdBlockingTest() {
        // given
        String id = "example";
        Integer maxResults = 56;
        String paginationToken = "example";

        // when
        GenericMultipleUsersLookupResponse body = api.usersIdBlocking(id, maxResults, paginationToken).block();

        // then
        // TODO implement the usersIdBlockingTest()
    }

    
    /**
     * Follow User
     *
     * Causes the user(in the path) to follow, or “request to follow” for protected users, the target user. The user(in the path) must match the user context authorizing the request
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdFollowTest() {
        // given
        String id = "example";
        UsersIdBlockRequest usersIdBlockRequest = new UsersIdBlockRequest("example");

        // when
        UsersFollowingCreateResponse body = api.usersIdFollow(id, usersIdBlockRequest).block();

        // then
        // TODO implement the usersIdFollowTest()
    }

    
    /**
     * Returns user objects that follow the provided user ID
     *
     * Returns a list of users that follow the provided user ID
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdFollowersTest() {
        // given
        String id = "example";
        Integer maxResults = 56;
        String paginationToken = "example";

        // when
        GenericMultipleUsersLookupResponse body = api.usersIdFollowers(id, maxResults, paginationToken).block();

        // then
        // TODO implement the usersIdFollowersTest()
    }

    
    /**
     * Following by User ID
     *
     * Returns a list of users that are being followed by the provided user ID
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdFollowingTest() {
        // given
        String id = "example";
        Integer maxResults = 56;
        String paginationToken = "example";

        // when
        UsersFollowingLookupResponse body = api.usersIdFollowing(id, maxResults, paginationToken).block();

        // then
        // TODO implement the usersIdFollowingTest()
    }

    
    /**
     * Mute User by User ID
     *
     * Causes the user (in the path) to mute the target user. The user (in the path) must match the user context authorizing the request
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdMuteTest() {
        // given
        String id = "example";
        UsersIdBlockRequest usersIdBlockRequest = new UsersIdBlockRequest("example");

        // when
        UsersMutingMutationResponse body = api.usersIdMute(id, usersIdBlockRequest).block();

        // then
        // TODO implement the usersIdMuteTest()
    }

    
    /**
     * Unblock User by User ID
     *
     * Causes the source user to unblock the target user. The source user must match the user context authorizing the request
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdUnblockTest() {
        // given
        String sourceUserId = "example";
        String targetUserId = "example";

        // when
        UsersBlockingMutationResponse body = api.usersIdUnblock(sourceUserId, targetUserId).block();

        // then
        // TODO implement the usersIdUnblockTest()
    }

    
    /**
     * Unfollow User
     *
     * Causes the source user to unfollow the target user. The source user must match the user context authorizing the request
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdUnfollowTest() {
        // given
        String sourceUserId = "example";
        String targetUserId = "example";

        // when
        UsersFollowingDeleteResponse body = api.usersIdUnfollow(sourceUserId, targetUserId).block();

        // then
        // TODO implement the usersIdUnfollowTest()
    }

    
    /**
     * Unmute User by User ID
     *
     * Causes the source user to unmute the target user. The source user must match the user context authorizing the request
     */
    @Test
    @Disabled("Not Implemented")
    public void usersIdUnmuteTest() {
        // given
        String sourceUserId = "example";
        String targetUserId = "example";

        // when
        UsersMutingMutationResponse body = api.usersIdUnmute(sourceUserId, targetUserId).block();

        // then
        // TODO implement the usersIdUnmuteTest()
    }

    
}
