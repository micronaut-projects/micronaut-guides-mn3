package example.micronaut.default.model;

import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;


/**
 * Model tests for BookAvailability
 */
@MicronautTest
public class BookAvailabilityTest {
    /**
     * Model tests for BookAvailability
     */
    @Test
    public void testBookAvailability() {
        // TODO: test BookAvailability
    }

}
