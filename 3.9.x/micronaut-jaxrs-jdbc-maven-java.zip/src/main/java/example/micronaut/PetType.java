package example.micronaut;

public enum PetType {
    DOG,
    CAT
}
