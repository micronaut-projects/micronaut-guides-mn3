package example.micronaut

import groovy.transform.CompileStatic

@CompileStatic
class BookResponse {
    String title
}
