package example.micronaut

data class BookRecommendation(val name: String)