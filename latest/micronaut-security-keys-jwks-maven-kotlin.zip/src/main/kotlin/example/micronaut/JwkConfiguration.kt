package example.micronaut

interface JwkConfiguration {

    val primary: String

    val secondary: String
}
