package example.micronaut

import groovy.transform.CompileStatic

@CompileStatic
class OutOfStockException extends RuntimeException {
}
