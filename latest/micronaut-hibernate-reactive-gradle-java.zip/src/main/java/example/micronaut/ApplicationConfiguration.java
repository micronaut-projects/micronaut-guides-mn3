package example.micronaut;

public interface ApplicationConfiguration {
    int getMax();
}
