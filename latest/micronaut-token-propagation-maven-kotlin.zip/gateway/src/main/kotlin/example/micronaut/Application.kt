package example.micronaut

import io.micronaut.runtime.Micronaut.run
fun main(args: Array<String>) {
	run(*args)
}

